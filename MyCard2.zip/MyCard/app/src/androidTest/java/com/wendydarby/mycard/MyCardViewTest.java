package com.wendydarby.mycard;

import android.content.Context;
import androidx.test.InstrumentationRegistry;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import androidx.test.rule.ActivityTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.core.IsNot.not;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class MyCardViewTest {

    @Rule
    public ActivityTestRule<MyCardView> activityRule = new ActivityTestRule<MyCardView>(MyCardView.class);

    @Test
    public void displayUsersDefaultElectronicCard(){
        Context context = InstrumentationRegistry.getContext();

        MyCardView.MyWebClient myWebClient = new MyCardView.MyWebClient();
        assertThat(myWebClient,not(empty()));

        onView(withId(R.id.webview)).perform(assertNotNull(hasItem(MyCardView.MyWebClient)));

        myWebClient = activityRule.getActivity();
        assertThat(myWebClient, not(empty));

    }

   /* @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testOnCreate() {
    }

    @Test
    public void testOnBackPressed() {
    }*/
}